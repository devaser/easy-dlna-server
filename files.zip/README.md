# Easy DLNA Server

A lightweight DLNA/UPnP media server for Windows. It runs as a Windows service, shares the folders you choose with DLNA clients (TVs, game consoles, media players) on your local network, and comes with a system tray app to control it.

## Components

| Executable | What it does |
|---|---|
| `EasyDLNAService.exe` | The Windows service: SSDP discovery (UDP 1900) and the HTTP media server (TCP 8200). |
| `EasyDLNATray.exe` | System tray app: start/stop the service, scan the library, open settings, open the service log. |
| `EasyDLNASettings.exe` | Settings window (shared folders). |
| `EasyDLNAScanner.exe` | Scans the shared folders and updates the media library. |

## Install

1. Download `EasyDLNASetup.exe` from the [Releases](https://github.com/devaser/EasyDLNAServer/releases) page.
2. Run it as administrator.
3. Leave **Allow Easy DLNA Server through Windows Firewall** selected so other devices on your network can find the server. This creates two inbound rules, only for the Easy DLNA service:
   - UDP 1900 (SSDP discovery)
   - TCP 8200 (HTTP)

   Both rules accept connections from the local subnet only, on the Private, Domain and Public profiles.

To install silently and skip the firewall rules:

```
EasyDLNASetup.exe /VERYSILENT /TASKS="!firewall"
```

Uninstalling removes the service, the firewall rules and the program files. The data stored in `%ProgramData%` is not touched.

## Build from source

Requirements: Windows and Python 3.13.

```
py -3.13 -m pip install -r requirements-dev.txt
```

Run the tray app from source:

```
py -3.13 tray.py
```

Build the executables (one `.spec` file per executable) and the installer:

```
py -3.13 -m PyInstaller EasyDLNAService.spec
py -3.13 -m PyInstaller EasyDLNATray.spec
py -3.13 -m PyInstaller EasyDLNAScanner.spec
py -3.13 -m PyInstaller EasyDLNASettings.spec
"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" EasyDLNASetup.iss
```

The installer is written for [Inno Setup](https://jrsoftware.org/isinfo.php) 6.3 or later. It needs the four executables in `dist\`, plus `LICENSE` and `THIRD_PARTY_NOTICES.md`.

## License

Copyright (C) 2026 [devaser](https://github.com/devaser)

Easy DLNA Server is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. See the [LICENSE](LICENSE) file for the full text.

Third-party components and their licenses are listed in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
